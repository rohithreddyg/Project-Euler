
import UIKit

func fibRecursive(stepNumber: Int) -> Int {
    if stepNumber == 1 || stepNumber == 2 {
        return 1
    }
    
    return fibRecursive(stepNumber: stepNumber - 1) + fibRecursive(stepNumber: stepNumber - 2)
}

fibRecursive(stepNumber: 10)


////////////////////////////////
var memoizedDictForFibSeries: [Int: Int] = [1: 1,
                                            2: 1]

func fibMemoizedRecursive(stepNumber: Int) -> Int {
    if let memoizedElement = memoizedDictForFibSeries[stepNumber] {
        return memoizedElement
    } else {
        let result = fibRecursive(stepNumber: stepNumber - 1) + fibRecursive(stepNumber: stepNumber - 2)
        memoizedDictForFibSeries[stepNumber] = result
        return result
    }
}

fibMemoizedRecursive(stepNumber: 10)


////////////////////////////////
func fibBottomUpApproach(stepNumber: Int) -> Int {
    if stepNumber == 1 || stepNumber == 2 {
        return 1
    }
    var fibSeries: [Int] = [1, 1]
    
    for index in 2..<stepNumber {
        fibSeries.append(fibSeries[index - 1] + fibSeries[index - 2])
    }
    return fibSeries[stepNumber - 1]
}

fibBottomUpApproach(stepNumber: 10)


////////////////////////////////
func fibonacciSeries(until input: Int) -> [Int] {
    var result = [1, 1]

    guard input > 1 else { return result }
    
    var sum = 0
    while sum <= input {
        let firstElement = result[result.count - 2]
        let secondElement = result[result.count - 1]
        sum = firstElement + secondElement
        if sum < input {
            result.append(sum)
        } else { return result }
    }
    return result
}

fibonacciSeries(until: 10)


//////////////////////////////
func fibonacciSeriesWithRecursion(steps: Int, first: Int, second: Int) -> [Int] {
    if steps > 0 {
        return [first + second] + fibonacciSeriesWithRecursion(steps: steps - 1, first: second, second: first + second)
    }
    return [first, second]
}

[0, 1] + fibonacciSeriesWithRecursion(steps: 10, first: 0, second: 1)


///////////////////////////////
func sumOfEvenFibonacci(until value: Int) -> Int {
    let fibUntilInput = fibonacciSeries(until: value)
    
    var sum = 0
    for number in fibUntilInput {
        if number % 2 == 0 {
            sum += number
        }
    }
    return sum
}

    
// Sum of Even numbers in Fibonacci Series below 4 million = 4613732
sumOfEvenFibonacci(until: 4000000)
