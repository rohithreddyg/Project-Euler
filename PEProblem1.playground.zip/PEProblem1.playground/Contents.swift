
import UIKit

func sumOfMultipleOf3or5(below input: Int) -> Int {
    var sum = 0
    
//    for index in 1..<input {
//        if index % 3 == 0 || index % 5 == 0 {
//            sum += index
//        }
//    }
    let filtered = (1..<input).filter {
        $0 % 3 == 0 || $0 % 5 == 0
    }
    sum = filtered.reduce(0, { $0 + $1 })
    return sum
}

sumOfMultipleOf3or5(below: 1000)
