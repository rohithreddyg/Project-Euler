import UIKit

func largestPrimeFactor(of number: Int) -> Int {
    var largestPrimeFactor = 1
    
    for index in 1...number {
        if number % index == 0 {
            if index > largestPrimeFactor {
                largestPrimeFactor = index
            }
        }
    }
    return largestPrimeFactor
}

largestPrimeFactor(of: 13195)

